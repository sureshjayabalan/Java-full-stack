package com.cg.payroll.daoservices;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Associate;

@Repository("payrollDaoservice")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	
	
	@Value("${dbusername}")
	public String dbusername;
	
	public  static HashMap<Integer, Associate> associates = new HashMap<>();
	public static int ASSOCIATE_ID_COUNTER =1000;

	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		
		return 0;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
	
		return false;
	}

	@Override
	public boolean deleteAssciate(int associateId) throws SQLException {
		
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) throws SQLException
	{
		System.out.println(dbusername);
		Associate a=new Associate();
		a.setFirstName("Suresh");
		a.setLastName("Jayabalan");
		return a;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		
		return null;
	}

	
}
