package com.cg.payroll.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

public class MainClass {
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		ApplicationContext applicationContext=new AnnotationConfigApplicationContext(AppConfig.class);
		PayrollServices service=applicationContext.getBean("payrollservice",PayrollServices.class);
		System.out.println(service);
		PayrollServices service1=applicationContext.getBean("payrollservice",PayrollServices.class);
		System.out.println(service1);
		
		 try {
			service.getAssociateDetails(2);
			System.out.println("Welcome "+service.getAssociateDetails(2).getFirstName()+" "+service.getAssociateDetails(2).getLastName());
		} catch (PayrollServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AssociateDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}