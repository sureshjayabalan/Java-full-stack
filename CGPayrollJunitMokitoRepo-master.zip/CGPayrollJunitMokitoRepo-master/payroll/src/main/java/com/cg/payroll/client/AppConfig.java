package com.cg.payroll.client;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@Configuration
@ComponentScan({"com.cg.payroll"})
@PropertySource("classpath:payroll.properties")
public class AppConfig 
{
	
	@Bean
	public static PropertyPlaceholderConfigurer configure()
	{
		PropertyPlaceholderConfigurer p=new PropertyPlaceholderConfigurer();
		//p.setIgnoreUnresolvablePlaceholders(true);
		return p;
	}
	
	@Bean(name="payrollservice")
	public PayrollServices getPayrollservice()
	{
		PayrollServices service = new PayrollServicesImpl();
		//service.setDaoServices(getPayrollDaoService());
		return service;
		
	}
	
	
	
//	@Bean(name="payrollDaoservice")
//	public PayrollDAOServices getPayrollDaoService()
//	{
//		return new PayrollDAOServicesImpl();
//	}
	
}
